
var tablinks = document.getElementsByClassName("p1")
var tabcontents = document.getElementsByClassName("permbajtja")

function opentab(tabname){
  for(tablink of tablinks){
      tablink.classList.remove("aktiv");
    }
  for(tabcontent of tabcontents){
      tabcontent.classList.remove("aktiv1");
    }
    event.currentTarget.classList.add("aktiv");//vendosja e efektit te underline edhe te pjesa tjeter e teksit
    document.getElementById(tabname).classList.add("aktiv1");//shfaqja e permbajtjes kur klikojme mbi fjalet eksperiencat dhe edukimi


}
//berja aktiv te simboleve qe kemi marre per ta bere me te lehte navigimin per ekranet me madhesi me te vogla
var menu1=document.getElementById("menu");
function openmenu(){
      menu1.style.right="0"; //ne momentin kur right=0 do kemi shfaqen e menuse
    }
function closemenu(){
      menu1.style.right="-200px"; //ne momentin kur right=-200 do kemi mbylljes e menuse-->
     
    }
    
